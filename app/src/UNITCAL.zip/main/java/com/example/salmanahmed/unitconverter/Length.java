package com.example.salmanahmed.unitconverter;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;

/**
 * Created by Salman Ahmed on 3/16/2017.
 */

public class Length extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.length);
        Intent intent = getIntent();


        Spinner dropdown = (Spinner) findViewById(R.id.spinner2);
        String[] items = new String[]{" Feet", "meters", "miles", "yards "};
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items);
        dropdown.setAdapter(adapter);

        Spinner dropdown1 = (Spinner) findViewById(R.id.spinner3);
        String[] items1 = new String[]{" Feet", "meters", "miles", "yards "};
        ArrayAdapter<String> adapter1= new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items1);
        dropdown1.setAdapter(adapter1);

        ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton4);
        imageButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View arg0) {

            }
        });
    }
}
